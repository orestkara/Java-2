
package basics;


public class Person extends Artist{

private  String Gender;
private  String BirthDate;
private  String DeathDate;



    public String getGender() {
        return Gender;
    }

   

    public String getBirthDate() {
        return BirthDate;
    }

    public String getDeathDate() {
        return DeathDate;
    }


    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public void setBirthDate(String BirthDate) {
        this.BirthDate = BirthDate;
    }

    public void setDeathDate(String DeathDate) {
        this.DeathDate = DeathDate;
    }

    public Person() {
    }

    public Person(String Name,String Country,String City,String Gender, String BirthDate, String DeathDate) {
        this.Name=Name;
        this.Country=Country;
        this.City=City;
        this.Gender = Gender;
        this.BirthDate = BirthDate;
        this.DeathDate = DeathDate;
    }
 
    
    
}
