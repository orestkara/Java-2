
package basics;




import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;


public class FileWrapper implements Serializable {
    
    
    
    public static void writeArtistsToFile(String filename, ArrayList<Artist> artArray){

        File myfile = new File(filename);

        if (!myfile.exists()) {
            try {
                myfile.createNewFile();
            
                try {
                //με αυτό κωδικιποιείς το array σε binary 
                    FileOutputStream fos = new FileOutputStream(filename);
                    ObjectOutputStream out = new ObjectOutputStream(fos);
                    out.writeObject(artArray);
                    out.close();
                    fos.close();
                    System.out.println("File Saved");
                } catch (IOException e) {
                    System.out.println("Error in output:" + e.toString());
                }
            }catch (IOException ex) {
                ex.printStackTrace();
            }
            
        }
    }
    
  public static ArrayList<Artist> readArtistsFromFile(String filename) {
        ArrayList<Artist> artArray = new ArrayList();
        String line;
    
        ArrayList<Artist> e = null;
            try {
                FileInputStream fileIn = new FileInputStream(filename);
                ObjectInputStream in = new ObjectInputStream(fileIn);
                e = (ArrayList) in.readObject();
                in.close();
                fileIn.close();
            } catch (IOException i) {
            } catch (ClassNotFoundException c) {
                System.out.println("Not found");
                
            }
          
        return e;
    }  
}
