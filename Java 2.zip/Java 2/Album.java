
package basics;

import java.util.ArrayList;


public class Album extends Release {
    
    private String AlbumTitle ;
    
    ArrayList<Release> TrackList = new ArrayList<>();

    public String getAlbumTitle() {
        return AlbumTitle;
    }

    public void setAlbumTitle(String AlbumTitle) {
        this.AlbumTitle = AlbumTitle;
    }

    public ArrayList<Release> getTrackList() {
        return TrackList;
    }

    public void setTrackList(ArrayList<Release> TrackList) {
        this.TrackList = TrackList;
    }

    public Album(String AlbumTitle) {
        this.AlbumTitle = AlbumTitle;
    }

    public Album() {
    }

   

    
}
