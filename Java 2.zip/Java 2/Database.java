  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basics;

import java.sql.*;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONObject;

/**
 *
 * @author vagge
 */


public class Database {

    public static void CreateDatabase() throws SQLException {
        try {
            String url = "jdbc:oracle:thin:@//10.100.51.123:1521/orcl";
            Connection conn = DriverManager.getConnection(url, "", "");
            Statement st = conn.createStatement();
            System.out.println("Creating table in given database...");
            Statement stmt1 = conn.createStatement();
            String sql = "CREATE TABLE ARTIST "
                    + "(id INTEGER not NULL, "
                    + " NAME VARCHAR(20), "
                    + " Country VARCHAR(20) "
                    + " City VARCHAR(20) "
                    + " PRIMARY KEY ( id ))";

            stmt1.executeUpdate(sql);

            System.out.println("Created table in given database...");

        } catch (SQLException e) {
            System.err.println("Got an exception! ");
        }
    }

    public static void InsertObject(Artist artist) {
       
       Random rand = new Random();
       String url = "jdbc:oracle:thin:@//10.100.51.123:1521/orcl";
            Connection conn;
        try {
            conn = DriverManager.getConnection(url, "", "");
              
            
            PreparedStatement ps = conn.prepareStatement("INSERT INTO ARTIST (id,NAME,Country,City) VALUES (?,?,?,?)");
            ps.setInt(1,rand.nextInt(10000));
            ps.setString(2, artist.Name);
             ps.setString(3,artist.Country);
              ps.setString(4, artist.City);
               
              ps.executeUpdate();
              System.out.println("Object succesfully added in Database!");
            
            
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
         
        
    }

    public static void InsertObjectsInList(ArrayList<Artist> artArray) {
       int i;
       for(i=0;i<artArray.size();i++){
           InsertObject(artArray.get(i));
           
       }
         System.out.println("Number of Objects added in Database:" + i );
    }

    public static ArrayList<Artist> ReturnListFromName(String keyword) {
        ArrayList<Artist> artArray = new ArrayList();
        try {
            String url = "jdbc:oracle:thin:@//10.100.51.123:1521/orcl";
            Connection conn = DriverManager.getConnection(url, "", "");
            Statement st = conn.createStatement();
            String sql;
            sql = "SELECT id,NAME,Country,City FROM ARTIST WHERE MUSIC=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(2, keyword);
            ResultSet rs = ps.executeQuery();
            String id;
            String name;
            String country;
            String  city;
            Artist nart = null ;
             
            while (rs.next()) {
                    int i=0;
                    id = rs.getString("id");
                    name = rs.getString("NAME");
                   country= rs.getString("Country");
                    city = rs.getString("City");
                    String line = (id + "    " + name + "    " + country+ "    " + city);
                    nart.Name=name;
                    nart.Country=country;
                    nart.City=city;
                    
                    artArray.add(nart);
                    
                    
                }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }  
        
         return artArray;
    }

}

    

    




    