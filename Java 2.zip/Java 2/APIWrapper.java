/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basics;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


/**
 *
 * @author koni
 */
public class APIWrapper {


    
    public static ArrayList<Artist> getSingerFromCountry(String singer, String country) {
        
        ArrayList<Artist> artArray = new ArrayList();
        //"http://musicbrainz.org/ws/2/artist/?query=artist:"+singer+"%20AND%20country:"+country+"&fmt=json"
        //http://musicbrainz.org/ws/2/artist/?query=artist:fred%20AND%20type:group&fmt=json
        String url="http://musicbrainz.org/ws/2/artist/?query=artist:"+singer+"%20AND%20country:"+country+"&fmt=json";
        StringBuffer response = new StringBuffer();
        
        
        try{
            URL obj = new URL(url);
            HttpURLConnection con= (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader (new
                    InputStreamReader(con.getInputStream()));
            String inputLine = null;
     
            while((inputLine = in.readLine())!= null){
                response.append(inputLine);
            }
            System.out.println(inputLine);
            in.close();
        }catch (Exception e){
            e.printStackTrace();
        }
       
        

        try {
            JSONObject jsonObject = new JSONObject(response.toString());
            JSONArray json_artists_list = jsonObject.getJSONArray("artists");
            
            for(int i=0; i<json_artists_list.length(); i++ ){

                JSONObject json_artist= json_artists_list.getJSONObject(i);

                
                  Person p1 = new Person();
                if(json_artist.has("type")){

                    if(json_artist.getString("type").equalsIgnoreCase("Person")){

                        if(json_artist.has("gender"))

                           p1.setGender(json_artist.getString("gender"));
                        
                        if(json_artist.has("begin"))
                            p1.setBirthDate(json_artist.getString("begin"));
                
                        if(json_artist.has("end"))
                            p1.setDeathDate(json_artist.getString("end"));
                        }
                    }

                if(json_artist.has("name"))
                    p1.setName(json_artist.getString("name"));

                if(json_artist.has("country"))
                     p1.setCountry(json_artist.getString("country"));
                
                if(json_artist.has("beginarea"))
                     p1.setCity(json_artist.getString("beginarea"));
                
                
                
                if(json_artist.has("alias"))
                     p1.Aliases.add(json_artist.getString("alias"));
                
                if(json_artist.has("tag"))
                     p1.Tags.add(json_artist.getString("tag"));
                
                
                
                
                artArray.add(p1);

            }
        
        } catch (JSONException ex) {
            ex.printStackTrace();
        }
        
        
        return artArray;
    
    
   
    
}
    public static ArrayList<Artist> getGroupFromCountry(String group, String country) {
        
        ArrayList<Artist> artArray = new ArrayList();
        //"http://musicbrainz.org/ws/2/artist/?query=artist:"+singer+"%20AND%20country:"+country+"&fmt=json"
        //http://musicbrainz.org/ws/2/artist/?query=artist:fred%20AND%20type:group&fmt=json
        String url="http://musicbrainz.org/ws/2/artist/?query=artist:"+group+"%20AND%20country:"+country+"&fmt=json";
        StringBuffer response = new StringBuffer();
        
        
        try{
            URL obj = new URL(url);
            HttpURLConnection con= (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader (new
                    InputStreamReader(con.getInputStream()));
            String inputLine = null;
     
            while((inputLine = in.readLine())!= null){
                response.append(inputLine);
            }
            System.out.println(inputLine);
            in.close();
        }catch (Exception e){
            e.printStackTrace();
        }
       
        

        try {
            JSONObject jsonObject = new JSONObject(response.toString());
            JSONArray json_artists_list = jsonObject.getJSONArray("artists");
            
            for(int i=0; i<json_artists_list.length(); i++ ){

                JSONObject json_artist= json_artists_list.getJSONObject(i);

                //Artist p1=new Person();1
                  Group g1 = new Group();
                if(json_artist.has("type")){

                    if(json_artist.getString("type").equalsIgnoreCase("group")){
                        System.out.println("HEY");
                        //if(json_artist.has("members"))
                        //g1.Members.add(json_artist.getString("members"));
                        
                    }
                }
                if(json_artist.has("name"))
                    g1.setName(json_artist.getString("name"));

                if(json_artist.has("country"))
                     g1.setCountry(json_artist.getString("country"));
                
                if(json_artist.has("beginarea"))
                     g1.setCity(json_artist.getString("beginarea"));
                
                if(json_artist.has("begin"))
                     g1.setBeginDate(json_artist.getString("begin"));
                
                if(json_artist.has("end"))
                     g1.setEndDate(json_artist.getString("end"));
                
                if(json_artist.has("alias"))
                     g1.Aliases.add(json_artist.getString("alias"));
                
                if(json_artist.has("tag"))
                     g1.Tags.add(json_artist.getString("tag"));
                
                
                
                
                artArray.add(g1);

            }
        
        } catch (JSONException ex) {
            ex.printStackTrace();
        }
        
        
        return artArray;
    
    
   
    
}

}
