
package basics;

import java.io.Serializable;
import java.util.ArrayList;


public abstract class Artist implements Serializable {
    
    public String Name ;
    public String Country ;
    public  String City;
    ArrayList<String> Aliases = new ArrayList<>();
    ArrayList<String> Tags = new ArrayList<>();

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public ArrayList<String> getAliases() {
        return Aliases;
    }

    public void setAliases(ArrayList<String> Aliases) {
        this.Aliases = Aliases;
    }

    public ArrayList<String> getTags() {
        return Tags;
    }

    public void setTags(ArrayList<String> Tags) {
        this.Tags = Tags;
    }
    
    
    
}
