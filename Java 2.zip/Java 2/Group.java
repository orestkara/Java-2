
package basics;

import java.util.ArrayList;
public class Group extends Artist {
    
    private String BeginDate;
    private String EndDate;
   
    ArrayList<Person> Members = new ArrayList<>();

    public String getBeginDate() {
        return BeginDate;
    }

    public String getEndDate() {
        return EndDate;
    }

    public ArrayList<Person> getMembers() {
        return Members;
    }

    public void setBeginDate(String BeginDate) {
        this.BeginDate = BeginDate;
    }

    public void setEndDate(String EndDate) {
        this.EndDate = EndDate;
    }

   

    public void setMembers(ArrayList<Person> Members) {
        this.Members = Members;
    }

    

    public Group() {
    }

    public Group(String Name,String Country,String City,String BeginDate, String EndDate) {
        this.Name=Name;
        this.Country=Country;
        this.City=City;
        this.BeginDate = BeginDate;
        this.EndDate = EndDate;
    }
    
    
    

    

    
}
