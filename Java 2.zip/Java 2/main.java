/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basics;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author koni
 */
public class main {
    public static void main(String[] args){
        
        
         
        ArrayList<Artist> artArray = new ArrayList();
        
        artArray=APIWrapper.getSingerFromCountry("Robbie","US");
        
        /*System.out.println(artArray.get(0).Name);
        System.out.println(artArray.get(1).Name);
        System.out.println(artArray.get(2).Name);
        System.out.println(artArray.get(3).Name);
        System.out.println(artArray.get(4).Name);
        System.out.println(artArray.get(1).Country);
        System.out.println(artArray.get(2).Country);
        System.out.println(artArray.get(3).Country);
        System.out.println(artArray.get(4).Country);
         System.out.println(artArray.get(1).City);
         System.out.println(artArray.get(1).Aliases);
         System.out.println(artArray.get(1).Tags);*/
         
         FileWrapper.writeArtistsToFile("artist.txt",artArray);
         
         
         
         
        
         ArrayList<Artist> lart = new ArrayList();
          
         lart = FileWrapper.readArtistsFromFile("artists.txt");
         
         
         ArrayList<Artist> results = new ArrayList();
        try {
            Database.CreateDatabase();
            Database.InsertObjectsInList(artArray);
            results=Database.ReturnListFromName("Robbie");
            
            System.out.println(results.get(0).Name);
            System.out.println(results.get(1).Name);
            System.out.println(results.get(2).Name);
            
            
            //System.out.println(lart.get(2).Name);
            //System.out.println(lart.get(3).Name);
            //ΓΙΑ ΚΑΠΟΙΟ ΛΟΓΟ ΕΝΩ ΔΟΥΛΕΥΕΙ ΕΤΣΙ ΑΝ ΒΑΛΩ ΝΑ ΤΥΠΩΣΕΙ ΤΗ ΛΙΣΤΑ ΔΕΝ ΤΟ ΚΑΝΕΙ ΚΑΙ ΧΤΥΠΑΕΙ ΕΡΡΟΡ
            
            
            /*ArrayList<Artist> artArray2 = new ArrayList();
            artArray=APIWR.getGroupFromCountry("Nirvana","US");
            System.out.println(artArray2.get(0).Name);
            System.out.println(artArray2.get(1).Name);
            System.out.println(artArray2.get(2).Name);
            System.out.println(artArray2.get(3).Name);
            System.out.println(artArray2.get(4).Name);
            System.out.println(artArray2.get(1).Country);
            System.out.println(artArray2.get(2).Country);
            System.out.println(artArray2.get(3).Country);
            System.out.println(artArray2.get(4).Country);
            System.out.println(artArray2.get(1).City);
            System.out.println(artArray2.get(1).Aliases);
            System.out.println(artArray2.get(1).Tags);
            
            */
        } catch (SQLException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
         
         
         
    }
    
    
    
}
