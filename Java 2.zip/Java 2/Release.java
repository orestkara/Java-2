
package basics;

import java.io.Serializable;


public abstract class Release implements Serializable{
    private String Title;
    private String Status;
    private String Language ;
    private String ReleaseDate;
    private String Format;
    private int TrackNum;
    private Artist ArtistName;

    public String getTitle() {
        return Title;
    }

    public String getStatus() {
        return Status;
    }

    public String getLanguage() {
        return Language;
    }

    public String getReleaseDate() {
        return ReleaseDate;
    }

    public String getFormat() {
        return Format;
    }

    public int getTrackNum() {
        return TrackNum;
    }

    public Artist getArtistName() {
        return ArtistName;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public void setLanguage(String Language) {
        this.Language = Language;
    }

    public void setReleaseDate(String ReleaseDate) {
        this.ReleaseDate = ReleaseDate;
    }

    public void setFormat(String Format) {
        this.Format = Format;
    }

    public void setTrackNum(int TrackNum) {
        this.TrackNum = TrackNum;
    }

    public void setArtistName(Artist ArtistName) {
        this.ArtistName = ArtistName;
    }

   

   
    
}