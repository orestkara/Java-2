
package basics;
import java.util.ArrayList;



public class Compilation extends Release {
    private String PlaylistName;
    ArrayList<Release> Playlist = new ArrayList<>();
    ArrayList<Artist> FeaturedArtists= new ArrayList<>();

    public String getPlaylistName() {
        return PlaylistName;
    }

    public void setPlaylistName(String PlaylistName) {
        this.PlaylistName = PlaylistName;
    }

    public ArrayList<Release> getPlaylist() {
        return Playlist;
    }

    public void setPlaylist(ArrayList<Release> Playlist) {
        this.Playlist = Playlist;
    }

    public ArrayList<Artist> getFeaturedArtists() {
        return FeaturedArtists;
    }

    public void setFeaturedArtists(ArrayList<Artist> FeaturedArtists) {
        this.FeaturedArtists = FeaturedArtists;
    }

    public Compilation(String PlaylistName) {
        this.PlaylistName = PlaylistName;
    }

    public Compilation() {
    }

   

    
}
